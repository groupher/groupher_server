defmodule GroupherServer.Mailer do
  @moduledoc """
  the email staff for Groupher
  """
  use Bamboo.Mailer, otp_app: :groupher_server
end
